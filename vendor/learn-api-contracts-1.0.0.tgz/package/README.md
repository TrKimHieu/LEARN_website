# LEARN API contracts 1.0.0

Public DTOs and runtime Zod schemas only. Install with Zod 4.6.4 or a compatible version. Web/native authentication state remains the responsibility of each client. The accompanying OpenAPI describes structural validation; server-side refinements, authorization and quota checks remain authoritative. No application implementation or source maps are shipped.
